package mastermindthesecond;
import java.util.*;
import java.lang.Math;

public class mastermindthefirst {

    public static void main(String[] args) {
    	Random random = new Random();
    	Scanner input = new Scanner(System.in);
        int black;
        black = 0;
        boolean won = false;
        String[] secret = new String[4];
        String colors[] = {"Red", "Blue", "Green", "Purple", "Orange", "Yellow"};
        System.out.println("Welcome to Mastermind");
        System.out.println("You can choose between the colors: red, blue, green, purple, orange and yellow");
        System.out.println("Black = Correct color on correct position");
        System.out.println("Gray = Incorrect color on incorrect position");
        System.out.println("White = Correct color on incorrect position");
        System.out.println("");
        System.out.println("Debug Mode? y/n");
        String answerInput = input.next();
    	String answerYes = ("Y");

        for (int i = 0; i < 4; i++) {
            int rng = random.nextInt(6);
            secret[i] = colors[rng];
            if (answerInput.equalsIgnoreCase(answerYes))
            System.out.println(secret[i]);
            else 
            System.out.println("Debug mode disabled");
            
        }
        for (int tenTurns = 1; tenTurns < 11; tenTurns++) { // 11 because the game will glitch out when it is '== 10'
        	System.out.println("Round: " + tenTurns); 
        	System.out.println("Choose 4 colors, 1 at a time:");
            String[] guess = new String[4];
            
            for (int i = 0; i < 4; i++) {
                guess[i] = input.next();
            }
            
            for (int i = 0; i < 4; i++) {
                String feedback;
                feedback = "Gray";
                if (guess[i].equalsIgnoreCase(secret[i])) {
                    feedback = "Black";
                    black = black + 1;
                } else {
                	for (int y = 0; y < 4; y++) {
                        if (secret[i].equalsIgnoreCase(guess[y]) && y != i) {
                            feedback = "White";
                        }
                    }
                }
                System.out.println(feedback);
                
            }
            if (black == 4) {
                tenTurns = 10;
                won = true;
                
            }
            black = 0;
        }
        if (won == true) {
            System.out.println("You have won! Restart for next round.");
            input.close();
        } else {
            System.out.println("You have lost! Restart for next round.");
            System.out.println("The code was:");
            for (int i = 0; i < 4; i++) {
            System.out.println(secret[i]);
            }
            input.close();
        }
    }
}